import sys
import copy

def get_min(q, min):
    # return min, which is the smallest starer point
    index = 0
    stop = 0
    while stop == 0:
        if q[index] > 0:  #when first element of queue is positive
            value = 0
            li=[]
            for i in range(len(q)):
                value += q[i]
                li.append(value)
            stop = 1   #to avoid infinite loop
            if check_neg(li) is True:  # adding values into "li" and check if any element is negative
                print min              # if negative, back to the function by recursion
            else:
                new_queue(q)
                min +=1
                stop = 1
                get_min(q, min)

        elif q[index] < 0:    #when first el of queue is negative
            new_queue(q)   # change first element of queue by adding a item that is popped
            min += 1
            stop = 1
            get_min(q, min)


def new_queue(q):
    q.append(q.pop(0))
    return q

def check_neg(list):
    count = 0
    for el in list:
        if el < 0:
            count += 1
    if count != 0:
        return False  # contains negative
    else:
        return True  # not contain



def main():
    with open(raw_input("Enter Filename: "), 'r') as f:
    #with open(sys.argv[1]) as f:
        global n
        energy = []
        n = int(f.readline().strip()) # n=4
        for i in range(n):
            in_data = f.readline().strip().split()
            E, D = int(in_data[0]), int(in_data[1])
            get_energy = E-D
            energy.append(get_energy)
        get_min(energy,0)   #0 : begin starter-point as 0


if __name__ == '__main__':
    main()

### Queue: remove from rear, insert from front