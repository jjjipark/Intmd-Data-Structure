import sys

def ProperBracket(S):
    open_bracket = "<{[("
    stack = []
    is_balanced = True
    index = 0
    while index < len(S) and is_balanced:
        bracket = S[index]
        if bracket in open_bracket:
            stack.insert(0, bracket)
        else:
            if len(stack) is 0:
                is_balanced = False
            else:
                top = stack.pop(0)
                #print(top)
                if is_match(top, bracket) is True:
                    #print bracket
                    return True
                else:
                    return False
        index += 1


def is_match(left, right):
    if left == '(' and right == ')':
        return True
    elif left == '[' and right == ']':
        return True
    elif left == '{' and right == '}':
        return True
    elif left == '<' and right == '>':
        return True
    else:
        return False


def main():
    #with open(raw_input("Enter Filename: "), 'r') as f:
    with open(sys.argv[1]) as f:
        n = int(f.readline().strip())
        #print(n)
        for _ in range(n):
            in_data = f.readline().strip().split()
            bracket_data = in_data[0]   # '1234'
            #print(bracket_data)  ##in_data -> ex. ['1234']
            if ProperBracket(bracket_data) is True:
                print ("YES")
            else:
                print ("NO")


if __name__ == '__main__':
    main()
