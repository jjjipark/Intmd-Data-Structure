class Node:

    def __init__(self, x):
        self.data = x
        self.next = None

class EmptyListError(Exception):
    pass

class LinkedList:

    def __init__(self):
        self.head = None
        self.tail = None

    def add_at_head(self, x):
        new_node = Node(x)
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head = new_node

    def remove_at_head(self):
        if self.is_empty():
            raise EmptyListError
        elif self.head.next is None:
            res = self.head.data
            self.head = None
            self.tail = None
            return res
        else:
            res = self.head.data
            self.head = self.head.next
            return res

    def add_at_tail(self, x):
        new_node = Node(x)
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node

    def is_empty(self):
        return self.head is None

    def __getitem__(self, data):
        return self.head